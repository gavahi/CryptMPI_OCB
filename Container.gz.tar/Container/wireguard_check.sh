#!/bin/bash

echo -e "kubectl get nodes  -o yaml | grep -i WireguardPublicKey"

kubectl get nodes  -o yaml | grep -i WireguardPublicKey
