kubectl delete -f p2p_pod.yml
