#!/bin/bash

RED='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${RED}systemctl enable kubelet/docker:${NC}"
sudo systemctl enable kubelet
sudo systemctl start kubelet
sudo systemctl enable docker
sudo systemctl start docker

echo -e "${RED}service firewalld stop:${NC}"
#service firewalld stop
sudo firewall-cmd --state


echo -e "${RED}systemctl daemon-reload${NC}"
sudo systemctl daemon-reload
sudo systemctl restart docker
sudo systemctl restart kubelet

echo -e "${RED}sudo swapoff -a${NC}"
sudo swapoff -a



echo -e "${RED}systemctl status kubelet/docker:${NC}"
sudo systemctl status docker
sudo systemctl status kubelet

#sleep 3

#echo -e "${RED}systemctl status kubelet/docker:${NC}"
#systemctl status kubelet
