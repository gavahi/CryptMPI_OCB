#!/bin/bash
USERNAME=gavahi
HOSTS="ns39 ns40 ns41 ns43 ns44 ns45 ns46"
SCRIPT="sudo kubeadm join 10.10.15.92:6443 --token i8v1ep.8kpoozg60ybql312   --discovery-token-ca-cert-hash sha256:0db57f9a088d33d11f5db094baf50f2df97de2eb9668c9408bdc7a50a9034933"
for HOSTNAME in ${HOSTS} ; do
   printf "\n\n$HOSTNAME \n"
    ssh -l ${USERNAME} ${HOSTNAME} "${SCRIPT}"
done
