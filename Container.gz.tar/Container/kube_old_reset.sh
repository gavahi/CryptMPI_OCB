#!/bin/sh

RED='\033[0;36m'
NC='\033[0m' # No Color

#for p in $(kubectl get pods | grep Terminating | awk '{print $1}'); do kubectl delete pod $p --grace-period=0 --force;done

echo -e "${RED}sudo kubeadm  reset -f ${NC}" && 
sudo kubeadm reset -f && 
echo -e "${RED}sudo systemctl stop kubelet${NC}" &&
sudo systemctl stop kubelet &&
echo -e "${RED}sudo systemctl stop docker${NC}" &&
sudo systemctl stop docker &&
echo -e "${RED}sudo rm -rf /var/lib/cni/${NC}" &&
sudo rm -rf /var/lib/cni/ &&
echo -e "${RED}sudo rm -rf /var/lib/kubelet/${NC}" &&
sudo rm -rf /var/lib/kubelet/* &&
echo -e "${RED}sudo rm -rf  /etc/cni/net.d/*"
sudo rm -rf  /etc/cni/net.d/*
#echo -e "${RED}sudo rm -rf /etc/cni/${NC}" &&
#sudo rm -rf /etc/cni/ &&
echo -e "${RED}sudo rm -rf /var/lib/calico/${NC}" &&
sudo rm -rf /var/lib/calico/ &&
echo -e "${RED}sudo rm -rf /var/lib/etcd/${NC}" &&
sudo rm -rf /var/lib/etcd/ &&
echo -e "${RED}sudo rm -rf /etc/kubernetes/${NC}" &&
sudo rm -rf /etc/kubernetes/ &&
#echo -e "${RED}sudo ifconfig cni0 down${NC}" &&
#sudo ifconfig cni0 down &&
echo -e "${RED}sudo ifconfig tunl0/flannel.1 down${NC}" &&
sudo ifconfig tunl0 down &&
echo -e "${RED}sudo ifconfig calif88fdc39bb5 down${NC}" &&
sudo ifconfig calif88fdc39bb5 down &&
echo -e "${RED}sudo ifconfig docker0 down${NC}" &&
sudo ifconfig docker0 down &&
echo -e "${RED}sudo ip link delete cni0${NC}" &&
sudo ip link delete cni0 &&
echo -e "${RED}sudo ip link delete tunl0/flannel.1"
sudo ip link delete tunl0
sudo ip link set cni0 down
sudo brctl delbr cni0
