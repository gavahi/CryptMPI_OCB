#!/bin/bash
docker version 
singularity version
sycri version
