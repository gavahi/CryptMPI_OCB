watch kubectl get pods -A -o=wide
