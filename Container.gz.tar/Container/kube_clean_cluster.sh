#!/bin/bash

#NODE=ns06
#WGET=54362112

#while read -a A; do echo ${A[1]}; done < ll


for NODE in ns37 ns39 ns40 ns41 ns42 ns43 ns44 ns45 ns46
do
ssh -t $NODE sudo ./kube_reset.sh
#ssh $NODE ipcs | grep gavahi
done

