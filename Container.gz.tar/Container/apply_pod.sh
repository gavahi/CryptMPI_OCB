kubectl apply -f pod.yml
