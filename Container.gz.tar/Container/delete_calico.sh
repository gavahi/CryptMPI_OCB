kubectl delete -f calico.yml
