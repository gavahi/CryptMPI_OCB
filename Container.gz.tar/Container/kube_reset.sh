#!/bin/sh

RED='\033[0;36m'
NC='\033[0m' # No Color

#for p in $(kubectl get pods | grep Terminating | awk '{print $1}'); do kubectl delete pod $p --grace-period=0 --force;done
sudo kubeadm reset -f 
sudo systemctl stop kubelet 
sudo systemctl stop docker 
sudo rm -rf /var/lib/cni/ 
sudo rm -rf /var/lib/kubelet/* 
sudo rm -rf  /etc/cni/net.d/*
sudo rm -rf /var/lib/calico/ 
sudo rm -rf /var/lib/etcd/ 
sudo rm -rf /etc/kubernetes/ 
sudo ifconfig cni0 down 
sudo ifconfig tunl0 down 
sudo ifconfig calif88fdc39bb5 down 
sudo ifconfig antrea-gw0 down
sudo ifconfig antrea-egress0 down
sudo ifconfig docker0 down 
sudo ip link delete cni0 
sudo ip link delete tunl0
sudo ip link delete antrea-gw0
sudo ip link delete antrea-egress0
sudo ip link set cni0 down 
sudo brctl delbr cni0 
echo -e "${RED}End of reset${NC}" 
sudo iptables -F && sudo iptables -t nat -F && sudo iptables -t mangle -F && sudo iptables -X && \
echo -e "${RED}Finish ${NC}" 
