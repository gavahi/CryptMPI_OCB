#!/bin/bash
docker ps | awk '{print $1}' > me
awk NR\>1 me > me2
while read -r line;
do
#   echo "$line" ;
docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}'  $line
#echo -e '-- '
done < me2
