PRIVKEY=id_rsa
TESTKEY=id_rsa.pub
diff -q  <( ssh-keygen -y -e -f "$PRIVKEY" ) <( ssh-keygen -y -e -f "$TESTKEY" )
