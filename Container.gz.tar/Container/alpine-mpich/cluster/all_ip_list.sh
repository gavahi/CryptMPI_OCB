#!/bin/bash
for i in ns37 ns39 ns41 ns42 ns43 ns44 ns45 ns46
do
	ssh $i 'cd /home/gavahi/docker/alpine-mpich4/cluster && ./ip.sh'
done	
