kubectl apply -f p2p_pod.yml
