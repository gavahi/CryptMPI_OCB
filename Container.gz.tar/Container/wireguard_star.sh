#!/bin/bash

echo -e "calicoctl patch felixconfiguration default --type='merge' -p '{"spec":{"wireguardEnabled":true}}'  --allow-version-mismatch"
calicoctl patch felixconfiguration default --type='merge' -p '{"spec":{"wireguardEnabled":true}}'  --allow-version-mismatch

