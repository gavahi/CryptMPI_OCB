#!/bin/bash

RED='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${RED}systemctl enable kubelet/sycri:${NC}"

sudo systemctl enable sycri
#sudo systemctl start sycri
sudo systemctl restart sycri

sudo systemctl enable kubelet
sudo systemctl start kubelet

echo -e "${RED}service firewalld stop:${NC}"
#service firewalld stop
sudo firewall-cmd --state


echo -e "${RED}systemctl daemon-reload${NC}"
sudo systemctl daemon-reload
sudo systemctl restart kubelet

echo -e "${RED}sudo swapoff -a${NC}"
sudo swapoff -a

echo -e "${RED}systemctl status sycri${NC}"
sudo systemctl status sycri


echo -e "${RED}systemctl status kubelet${NC}"
systemctl status kubelet

