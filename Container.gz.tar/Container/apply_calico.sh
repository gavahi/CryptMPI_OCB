kubectl apply -f calico.yml
