#!/bin/bash
systemctl enable kubelet
systemctl start kubelet
systemctl enable docker
systemctl start docker
service firewalld stop
sudo firewall-cmd --state
echo "sudo swapoff -a"
sudo swapoff -a
