kubectl delete -f pod.yml
