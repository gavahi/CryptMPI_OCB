sudo firewall-cmd --state
sudo systemctl status docker
sudo systemctl status kubelet

