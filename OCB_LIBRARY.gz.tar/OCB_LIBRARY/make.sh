rm libocb.so   ocb.o
gcc  -march=native -O3 -c -fPIC ocb.c -o ocb.o
gcc -shared -o libocb.so -fPIC ocb.o



