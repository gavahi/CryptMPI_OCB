#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>   
#include <stdlib.h>
#include <stdint.h>
#include "ae.h"


#if __GNUC__
#define ALIGN(n)      __attribute__ ((aligned(n))) 
#elif _MSC_VER
#define ALIGN(n)      __declspec(align(n))
#else
#define ALIGN(n)
#endif


#if __INTEL_COMPILER
  #define STAMP ((unsigned)__rdtsc())
#elif (__GNUC__ && (__x86_64__ || __amd64__ || __i386__))
  #define STAMP ({unsigned res; __asm__ __volatile__ ("rdtsc" : "=a"(res) : : "edx"); res;})
#elif (_M_IX86)
  #include <intrin.h>
  #pragma intrinsic(__rdtsc)
  #define STAMP ((unsigned)__rdtsc())
#else
  #error -- Architechture not supported!
#endif


#ifndef MAX_ITER
#define MAX_ITER 1024
#endif


#define sz 819200
#define ad_len 0 
#define iteration   1000//1000000 //1M
#define max_data 7//10 //num of input data



ALIGN(16)  unsigned char buf[sz]; //buf_2[sz],buf_3[sz],buf_4[sz];
ALIGN(16)  unsigned char cipher[sz]={0}; //cipher_2[sz],cipher_3[sz],cipher_4[sz];
ALIGN(16)  unsigned char recv[sz]; //recv_2[sz],recv_3[sz],recv_4[sz];


int key_len, outlen_enc, outlen_dec;

ALIGN(16) char tag[16], tag_2[16], tag_3[16], tag_4[16];
ALIGN(16) unsigned char key[] = "abcdefghijklmnop";
ALIGN(16) unsigned char nonce[16];
ALIGN(16) unsigned char dec_nonce[16];
ALIGN(16) unsigned char dec_nonce_2[16];
ALIGN(16) unsigned char dec_nonce_3[16];
ALIGN(16) unsigned char dec_nonce_4[16];
ALIGN(16) char pt[sz] = {0};
char outbuf[MAX_ITER*15+1024];


int length[64] ={ 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192};


ae_ctx* ctx;
ae_ctx* ctx_2;
ae_ctx* ctx_3;
ae_ctx* ctx_4;

ae_ctx* dec_ctx;


void bench_ocb(){
    
    int j, k, res;
    double latency_us;
    long long i, my_time;
    unsigned my_iter;
    clockid_t id = CLOCK_MONOTONIC_RAW;
    struct timespec start, end;

#if 0
    my_iter = iteration;
    for(k = 0; k < max_data; k++){
        i=length[k];
        
        clock_gettime(id, &start);
        for(j=1;j<=my_iter; j++){
            
          //ae_encrypt(ctx, buf, i, cipher);
          ocb_encrypt(ctx, ctx_2, ctx_3, ctx_4, buf, i, cipher, 1);
          //res = ae_decrypt(ctx, cipher, i,  recv);
          res = ocb_decrypt(ctx, ctx_2, ctx_3, ctx_4, cipher, i, recv, 1);
          if (res == -1) { 
            printf("(OCB)Authentication error\n"); fflush(stdout);
            return; 
          }   
        }
        clock_gettime(id,&end);

        my_time = ((long long)(end.tv_sec - start.tv_sec))*1000000000 + (end.tv_nsec - start.tv_nsec);
        latency_us = (((my_time)/(iteration))/1.0);//latency in us

        printf(" %f\n", latency_us ); //Cycles per Byte
        sleep(2);
    }

    printf("------------------[1]--- OCB--done---------------iteration=%d\n\n", iteration);fflush(stdout);
#endif

#if 1
    my_iter =(iteration/2);
    for(k = 0; k < max_data; k++){
        i=length[k];


        int loop;
        unsigned long p_start, c_start;


        clock_gettime(id, &start);
        for(j=1;j<= my_iter; j++){
          /*Total 128 ranks, handle 2 messages at time, need 64 iterations*/
          for(loop=0;loop<128;loop+=2){

            p_start = (i)*loop;
            c_start = (i+28)*loop;

            ocb_encrypt(ctx, ctx_2, ctx_3, ctx_4, (buf+p_start), i, (cipher+c_start), 2);
            res = ocb_decrypt(ctx, ctx_2, ctx_3, ctx_4, (cipher+c_start), i, (recv+p_start), 2);

            if (res == -1) { 
              printf("(OCB_Ur_2)Authentication error\n"); fflush(stdout);
              return; 
            }  
          } 
        }
        clock_gettime(id,&end);

        my_time = ((long long)(end.tv_sec - start.tv_sec))*1000000000 + (end.tv_nsec - start.tv_nsec);
        latency_us = (((my_time)/(iteration))/1.0);

        printf(" %f\n", latency_us ); //latency in us
        sleep(2);
    }

    printf("------------------[2]--- OCB_Ur_2-----------------iteration=%d\n\n", iteration);fflush(stdout);
#endif
  

#if 1
    my_iter =(iteration/4);
    for(k = 0; k < max_data; k++){

        i=length[k];

        int loop;
        unsigned long p_start, c_start;
        
        clock_gettime(id, &start);
        for(j=1;j<=my_iter; j++){

          /*Total 128 ranks, handle 4 messages at time, need 32 iterations*/
          for(loop=0;loop<128;loop+=4){

            p_start = (i)*loop;
            c_start = (i+28)*loop;

            ocb_encrypt(ctx, ctx_2, ctx_3, ctx_4,  (buf+p_start), i, (cipher+c_start), 4);
            res = ocb_decrypt(ctx, ctx_2, ctx_3, ctx_4, (cipher+c_start), i, (recv+p_start), 4);

            if (res == -1) { 
              printf("(OCB_Ur_4)Authentication error\n"); fflush(stdout);
              return; 
            }   
          }
        }
        clock_gettime(id,&end);

        my_time = ((long long)(end.tv_sec - start.tv_sec))*1000000000 + (end.tv_nsec - start.tv_nsec);
        latency_us = (((my_time)/(iteration))/1.0);

        printf(" %f\n", latency_us ); //latency in us
    }

    printf("--------------------- OCB_Ur_4-----------------iteration=%d\n\n", iteration);fflush(stdout);
#endif
}


int main(int argc, char *argv[]){

    memset(buf,'a',(sz-400));
    memset(recv,'b',(sz-400));


    ctx = ae_allocate(NULL);
    ctx_2 = ae_allocate(NULL);
    ctx_3 = ae_allocate(NULL);
    ctx_4 = ae_allocate(NULL);


    //ae_enc_init(ctx, key, 16, 16, nonce);
    ae_enc_init(ctx, key, 16);
    ae_init(ctx_2, key, 16,  12,16);
    ae_init(ctx_3, key, 16, 12, 16);
    ae_init(ctx_4, key, 16, 12, 16);
 
    bench_ocb();

    ae_free(ctx);
    ae_free(ctx_2);
    ae_free(ctx_3);
    ae_free(ctx_4);

    return 0;
}